import express from 'express';
import { collectAllSignals } from '../services/signalCollector.js';
import { calculateScore } from '../services/scoringEngine.js';
import { getCache, setCache } from '../services/cache.js';
import { normalizeUrl } from '../utils/urlParser.js';

const router = express.Router();

router.post('/analyze', async (req, res) => {
  try {
    const { url } = req.body;

    if (!url) {
      return res.status(400).json({ error: 'URL is required' });
    }

    const normalizedUrl = normalizeUrl(url);
    
    // Check cache
    const cached = getCache(normalizedUrl);
    if (cached) {
      return res.json({ ...cached, cached: true });
    }

    // Collect signals
    const signals = await collectAllSignals(normalizedUrl);
    
    // Calculate score
    const result = calculateScore(signals, normalizedUrl);
    
    // Cache result
    setCache(normalizedUrl, result);

    res.json({ ...result, cached: false });
  } catch (error) {
    console.error('Analysis error:', error);
    res.status(500).json({
      error: 'Analysis failed',
      message: error.message
    });
  }
});

export default router;
