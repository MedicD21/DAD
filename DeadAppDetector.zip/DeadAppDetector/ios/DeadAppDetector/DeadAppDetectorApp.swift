import SwiftUI

@main
struct DeadAppDetectorApp: App {
    var body: some Scene {
        WindowGroup {
            InputView()
        }
    }
}
