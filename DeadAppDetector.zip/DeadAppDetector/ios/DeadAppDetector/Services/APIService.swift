import Foundation

class APIService {
    static let shared = APIService()
    
    private let baseURL = "http://localhost:3000/api/v1"
    
    private init() {}
    
    func analyzeApp(url: String) async throws -> AnalysisResult {
        guard let endpoint = URL(string: "\(baseURL)/analyze") else {
            throw APIError.invalidURL
        }
        
        var request = URLRequest(url: endpoint)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        
        let body = ["url": url]
        request.httpBody = try JSONEncoder().encode(body)
        
        let (data, response) = try await URLSession.shared.data(for: request)
        
        guard let httpResponse = response as? HTTPURLResponse else {
            throw APIError.invalidResponse
        }
        
        guard httpResponse.statusCode == 200 else {
            throw APIError.serverError(httpResponse.statusCode)
        }
        
        let decoder = JSONDecoder()
        return try decoder.decode(AnalysisResult.self, from: data)
    }
    
    enum APIError: LocalizedError {
        case invalidURL
        case invalidResponse
        case serverError(Int)
        
        var errorDescription: String? {
            switch self {
            case .invalidURL:
                return "Invalid URL provided"
            case .invalidResponse:
                return "Invalid response from server"
            case .serverError(let code):
                return "Server error: \(code)"
            }
        }
    }
}
